# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'class'
#

DROP TABLE IF EXISTS class;
CREATE TABLE class (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   class varchar(150) NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, class),
   UNIQUE row_id_2 (row_id)
);


# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'class_to_project'
#

DROP TABLE IF EXISTS class_to_project;
CREATE TABLE class_to_project (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   class_id int(11) DEFAULT '0' NOT NULL,
   project_id int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, class_id, project_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'description'
#

DROP TABLE IF EXISTS description;
CREATE TABLE description (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   text blob NOT NULL,
   language_id tinyint(4) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, language_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'description_to_class'
#

DROP TABLE IF EXISTS description_to_class;
CREATE TABLE description_to_class (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   description_id int(11) DEFAULT '0' NOT NULL,
   class_id int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, description_id, class_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'description_to_function'
#

DROP TABLE IF EXISTS description_to_function;
CREATE TABLE description_to_function (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   description_id int(11) DEFAULT '0' NOT NULL,
   function_id int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, description_id, function_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'description_to_parameter'
#

DROP TABLE IF EXISTS description_to_parameter;
CREATE TABLE description_to_parameter (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   description_id int(11) DEFAULT '0' NOT NULL,
   parameter_id int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, description_id, parameter_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'description_to_project'
#

DROP TABLE IF EXISTS description_to_project;
CREATE TABLE description_to_project (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   description_id int(11) DEFAULT '0' NOT NULL,
   project_id int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, description_id, project_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'example'
#

DROP TABLE IF EXISTS example;
CREATE TABLE example (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   text blob NOT NULL,
   language_id tinyint(4) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, language_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'example_to_class'
#

DROP TABLE IF EXISTS example_to_class;
CREATE TABLE example_to_class (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   example_id int(11) DEFAULT '0' NOT NULL,
   class_id int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, example_id, class_id),
   UNIQUE row_id_2 (row_id)
);


# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'example_to_function'
#

DROP TABLE IF EXISTS example_to_function;
CREATE TABLE example_to_function (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   example_id int(11) DEFAULT '0' NOT NULL,
   function_id int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, example_id, function_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'example_to_parameter'
#

DROP TABLE IF EXISTS example_to_parameter;
CREATE TABLE example_to_parameter (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   example_id int(11) DEFAULT '0' NOT NULL,
   parameter_id int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, example_id, parameter_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'function'
#

DROP TABLE IF EXISTS function;
CREATE TABLE function (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   name varchar(150) NOT NULL,
   return varchar(255) NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'function_to_class'
#

DROP TABLE IF EXISTS function_to_class;
CREATE TABLE function_to_class (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   function_id int(11) DEFAULT '0' NOT NULL,
   class_id int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, function_id, class_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'language'
#

DROP TABLE IF EXISTS language;
CREATE TABLE language (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   language varchar(50) NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, language),
   UNIQUE row_id_2 (row_id)
);

#
# Daten f�r Tabelle 'language'
#

INSERT INTO language VALUES( '1', 'German');
INSERT INTO language VALUES( '2', 'English');

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'parameter'
#

DROP TABLE IF EXISTS parameter;
CREATE TABLE parameter (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   name varchar(255) NOT NULL,
   type varchar(255),
   PRIMARY KEY (row_id),
   KEY row_id (row_id),
   UNIQUE row_id_2 (row_id)
);


# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'parameter_to_function'
#

DROP TABLE IF EXISTS parameter_to_function;
CREATE TABLE parameter_to_function (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   parameter_id int(11) DEFAULT '0' NOT NULL,
   function_id int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, parameter_id, function_id),
   UNIQUE row_id_2 (row_id)
);


# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'project'
#

DROP TABLE IF EXISTS project;
CREATE TABLE project (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   name varchar(255) NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id),
   UNIQUE row_id_2 (row_id)
);

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'system_text'
#

DROP TABLE IF EXISTS system_text;
CREATE TABLE system_text (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   template_name varchar(50) NOT NULL,
   text blob NOT NULL,
   language_id int(11) DEFAULT '0' NOT NULL,
   name varchar(50) NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id, template_name, language_id),
   UNIQUE row_id_2 (row_id),
   KEY name (name)
);

#
# Daten f�r Tabelle 'system_text'
#

INSERT INTO system_text VALUES( '1', 'index2.php4', 'System for multilingual PHP class documentation', '2', 'headline');
INSERT INTO system_text VALUES( '2', 'index2.php4', 'Projects', '2', 'projects');
INSERT INTO system_text VALUES( '3', 'index2.php4', 'view project', '2', 'view_project');
INSERT INTO system_text VALUES( '4', 'index2.php4', 'edit project', '2', 'edit_project');
INSERT INTO system_text VALUES( '5', 'index2.php4', 'delete project', '2', 'delete_project');
INSERT INTO system_text VALUES( '6', 'index2.php4', 'Add a new project', '2', 'add_project');
INSERT INTO system_text VALUES( '7', 'index2.php4', 'System f�r mehrsprachige PHP Klassen Dokumentation', '1', 'headline');
INSERT INTO system_text VALUES( '8', 'index2.php4', 'Projekte', '1', 'projects');
INSERT INTO system_text VALUES( '9', 'index2.php4', 'Projekt anzeigen', '1', 'view_project');
INSERT INTO system_text VALUES( '10', 'index2.php4', 'Projekt bearbeiten', '1', 'edit_project');
INSERT INTO system_text VALUES( '11', 'index2.php4', 'Projekt l�schen', '1', 'delete_project');
INSERT INTO system_text VALUES( '12', 'index2.php4', 'Ein neues Projekt hinzuf�gen', '1', 'add_project');
INSERT INTO system_text VALUES( '13', 'treemenu.php4', 'Projects', '2', 'projects');
INSERT INTO system_text VALUES( '14', 'treemenu.php4', 'Classes', '2', 'classes');
INSERT INTO system_text VALUES( '15', 'treemenu.php4', 'Functions', '2', 'functions');
INSERT INTO system_text VALUES( '16', 'treemenu.php4', 'Refresh', '2', 'refresh');
INSERT INTO system_text VALUES( '25', 'project.php4', 'Apply changes', '2', 'apply_changes');
INSERT INTO system_text VALUES( '24', 'project.php4', 'Enter a description for the project', '2', 'enter_description');
INSERT INTO system_text VALUES( '23', 'project.php4', 'Enter the name for the project', '2', 'enter_name');
INSERT INTO system_text VALUES( '22', 'project.php4', 'Edit this project', '2', 'edit');
INSERT INTO system_text VALUES( '21', 'project.php4', 'Project information', '2', 'information');
INSERT INTO system_text VALUES( '20', 'treemenu.php4', 'Aktualisieren', '1', 'refresh');
INSERT INTO system_text VALUES( '19', 'treemenu.php4', 'Projekte', '1', 'projects');
INSERT INTO system_text VALUES( '18', 'treemenu.php4', 'Funktionen', '1', 'functions');
INSERT INTO system_text VALUES( '17', 'treemenu.php4', 'Klassen', '1', 'classes');
INSERT INTO system_text VALUES( '26', 'project.php4', 'The project has been changed', '2', 'changed');
INSERT INTO system_text VALUES( '27', 'project.php4', 'Add a new project', '2', 'add_project');
INSERT INTO system_text VALUES( '28', 'project.php4', 'Add this new project', '2', 'add_this');
INSERT INTO system_text VALUES( '29', 'project.php4', 'The new project has been created', '2', 'created');
INSERT INTO system_text VALUES( '30', 'project.php4', 'Really delete this project', '2', 'really_delete');
INSERT INTO system_text VALUES( '31', 'project.php4', 'Project name', '2', 'name');
INSERT INTO system_text VALUES( '32', 'project.php4', 'Project description', '2', 'description');
INSERT INTO system_text VALUES( '33', 'project.php4', 'yes', '2', 'yes');
INSERT INTO system_text VALUES( '34', 'project.php4', 'no', '2', 'no');
INSERT INTO system_text VALUES( '35', 'project.php4', 'The selected project has been deleted', '2', 'deleted');
INSERT INTO system_text VALUES( '36', 'project.php4', 'Please go to the', '2', 'go_back1');
INSERT INTO system_text VALUES( '68', 'project.php4', 'index page', '2', 'go_back2');
INSERT INTO system_text VALUES( '37', 'project.php4', 'edit project', '2', 'edit_project');
INSERT INTO system_text VALUES( '38', 'project.php4', 'delete project', '2', 'delete_project');
INSERT INTO system_text VALUES( '40', 'project.php4', 'Classes', '2', 'classes');
INSERT INTO system_text VALUES( '41', 'project.php4', 'view class', '2', 'view_class');
INSERT INTO system_text VALUES( '42', 'project.php4', 'edit class', '2', 'edit_class');
INSERT INTO system_text VALUES( '43', 'project.php4', 'delete class', '2', 'delete_class');
INSERT INTO system_text VALUES( '44', 'project.php4', 'Add a new class', '2', 'add_class');
INSERT INTO system_text VALUES( '89', 'project.php4', 'nein', '1', 'no');
INSERT INTO system_text VALUES( '87', 'project.php4', 'Projektinformation', '1', 'information');
INSERT INTO system_text VALUES( '90', 'project.php4', 'Dieses Projekt wirklich l�schen', '1', 'really_delete');
INSERT INTO system_text VALUES( '85', 'project.php4', 'Bitte gehen Sie zur', '1', 'go_back1');
INSERT INTO system_text VALUES( '86', 'project.php4', 'Index Seite', '1', 'go_back2');
INSERT INTO system_text VALUES( '84', 'project.php4', 'Geben Sie den Namen f�r das Projekt ein', '1', 'enter_name');
INSERT INTO system_text VALUES( '83', 'project.php4', 'Geben Sie eine Beschreibung f�r das Projekt ein', '1', 'enter_description');
INSERT INTO system_text VALUES( '82', 'project.php4', 'Projekt �ndern', '1', 'edit_project');
INSERT INTO system_text VALUES( '81', 'project.php4', 'Klasse �ndern', '1', 'edit_class');
INSERT INTO system_text VALUES( '80', 'project.php4', 'Diese Projekt �ndern', '1', 'edit');
INSERT INTO system_text VALUES( '79', 'project.php4', 'Projektbeschreibung', '1', 'description');
INSERT INTO system_text VALUES( '78', 'project.php4', 'Projekt l�schen', '1', 'delete_project');
INSERT INTO system_text VALUES( '77', 'project.php4', 'Klasse l�schen', '1', 'delete_class');
INSERT INTO system_text VALUES( '74', 'project.php4', 'Klassen', '1', 'classes');
INSERT INTO system_text VALUES( '76', 'project.php4', 'Das gew�hlte Projekt wurde gel�scht.', '1', 'deleted');
INSERT INTO system_text VALUES( '75', 'project.php4', 'Das neue Projekt wurde erstellt.', '1', 'created');
INSERT INTO system_text VALUES( '73', 'project.php4', 'Das Projekt wurde ge�ndert', '1', 'changed');
INSERT INTO system_text VALUES( '72', 'project.php4', '�nderungen durchf�hren', '1', 'apply_changes');
INSERT INTO system_text VALUES( '88', 'project.php4', 'Projektname', '1', 'name');
INSERT INTO system_text VALUES( '71', 'project.php4', 'Dieses neue Projekt hinzuf�gen', '1', 'add_this');
INSERT INTO system_text VALUES( '70', 'project.php4', 'Ein neues Projekt hinzuf�gen', '1', 'add_project');
INSERT INTO system_text VALUES( '69', 'project.php4', 'Eine neue Klasse hinzuf�gen', '1', 'add_class');
INSERT INTO system_text VALUES( '91', 'project.php4', 'Klasse anzeigen', '1', 'view_class');
INSERT INTO system_text VALUES( '92', 'project.php4', 'yes', '1', 'yes');
INSERT INTO system_text VALUES( '93', 'class.php4', 'Class information', '2', 'class_information');
INSERT INTO system_text VALUES( '94', 'class.php4', 'Edit this class', '2', 'edit_class');
INSERT INTO system_text VALUES( '95', 'class.php4', 'Enter the name of the class', '2', 'enter_name');
INSERT INTO system_text VALUES( '96', 'class.php4', 'Enter a description for the class', '2', 'enter_description');
INSERT INTO system_text VALUES( '97', 'class.php4', 'Enter a example for the use of the class', '2', 'enter_example');
INSERT INTO system_text VALUES( '98', 'class.php4', 'Apply changes', '2', 'apply_changes');
INSERT INTO system_text VALUES( '99', 'class.php4', 'The class has been changed', '2', 'changed');
INSERT INTO system_text VALUES( '100', 'class.php4', 'Add a new class', '2', 'add_class');
INSERT INTO system_text VALUES( '101', 'class.php4', 'The new class has been created', '2', 'created');
INSERT INTO system_text VALUES( '102', 'class.php4', 'Really delete this class', '2', 'really_delete');
INSERT INTO system_text VALUES( '103', 'class.php4', 'Class name', '2', 'name');
INSERT INTO system_text VALUES( '104', 'class.php4', 'Class description', '2', 'description');
INSERT INTO system_text VALUES( '105', 'class.php4', 'Class use example', '2', 'example');
INSERT INTO system_text VALUES( '106', 'class.php4', 'Yes', '2', 'yes');
INSERT INTO system_text VALUES( '107', 'class.php4', 'No', '2', 'no');
INSERT INTO system_text VALUES( '108', 'class.php4', 'The selected project has been deleted', '2', 'deleted');
INSERT INTO system_text VALUES( '109', 'class.php4', 'Please go to the', '2', 'go_back1');
INSERT INTO system_text VALUES( '110', 'class.php4', 'index page', '2', 'go_back2');
INSERT INTO system_text VALUES( '111', 'class.php4', 'edit class', '2', 'edit_class2');
INSERT INTO system_text VALUES( '112', 'class.php4', 'delete class', '2', 'delete_class');
INSERT INTO system_text VALUES( '113', 'class.php4', 'List of functions', '2', 'list_functions');
INSERT INTO system_text VALUES( '114', 'class.php4', 'view function', '2', 'view_function');
INSERT INTO system_text VALUES( '115', 'class.php4', 'edit function', '2', 'edit_function');
INSERT INTO system_text VALUES( '116', 'class.php4', 'delete function', '2', 'delete_function');
INSERT INTO system_text VALUES( '117', 'class.php4', 'Add a new function', '2', 'add_function');
INSERT INTO system_text VALUES( '118', 'class.php4', 'Back to the parent project', '2', 'back_to');
INSERT INTO system_text VALUES( '119', 'class.php4', 'Eine neue Klasse hinzuf�gen', '1', 'add_class');
INSERT INTO system_text VALUES( '120', 'class.php4', 'Eine neue Funkion hinzuf�gen', '1', 'add_function');
INSERT INTO system_text VALUES( '121', 'class.php4', '�nderungen �bernehmen', '1', 'apply_changes');
INSERT INTO system_text VALUES( '122', 'class.php4', 'Zur�ck zum Eltern-Objekt', '1', 'back_to');
INSERT INTO system_text VALUES( '123', 'class.php4', 'Die Klasse wurde ge�ndert', '1', 'changed');
INSERT INTO system_text VALUES( '124', 'class.php4', 'Klasseninformation', '1', 'class_information');
INSERT INTO system_text VALUES( '125', 'class.php4', 'Die neue Klasse wurde erstellt', '1', 'created');
INSERT INTO system_text VALUES( '126', 'class.php4', 'Das gew�hlte Projekt wurde gel�scht', '1', 'deleted');
INSERT INTO system_text VALUES( '127', 'class.php4', 'Klasse l�schen', '1', 'delete_class');
INSERT INTO system_text VALUES( '128', 'class.php4', 'Funktion l�schen', '1', 'delete_function');
INSERT INTO system_text VALUES( '129', 'class.php4', 'Klassenbeschreibung', '1', 'description');
INSERT INTO system_text VALUES( '130', 'class.php4', 'Diese Klasse bearbeiten', '1', 'edit_class');
INSERT INTO system_text VALUES( '131', 'class.php4', 'Klasse bearbeiten', '1', 'edit_class2');
INSERT INTO system_text VALUES( '132', 'class.php4', 'Funktion bearbeiten', '1', 'edit_function');
INSERT INTO system_text VALUES( '133', 'class.php4', 'Geben Sie eine Beschreibung f�r die Klasse ein', '1', 'enter_description');
INSERT INTO system_text VALUES( '134', 'class.php4', 'Geben Sie Beispiel f�r die Verwendung der Klasse an', '1', 'enter_example');
INSERT INTO system_text VALUES( '135', 'class.php4', 'Geben Sie den Namen der Klasse ein', '1', 'enter_name');
INSERT INTO system_text VALUES( '136', 'class.php4', 'Klassen Verwendungsbeispiel', '1', 'example');
INSERT INTO system_text VALUES( '137', 'class.php4', 'Bitte gehen Sie zur', '1', 'go_back1');
INSERT INTO system_text VALUES( '138', 'class.php4', 'Index Seite', '1', 'go_back2');
INSERT INTO system_text VALUES( '139', 'class.php4', 'Funktionenliste', '1', 'list_functions');
INSERT INTO system_text VALUES( '140', 'class.php4', 'Klassenname', '1', 'name');
INSERT INTO system_text VALUES( '141', 'class.php4', 'Nein', '1', 'no');
INSERT INTO system_text VALUES( '142', 'class.php4', 'Diese Klasse wirklich l�schen?', '1', 'really_delete');
INSERT INTO system_text VALUES( '143', 'class.php4', 'Funktion anzeigen', '1', 'view_function');
INSERT INTO system_text VALUES( '144', 'class.php4', 'Ja', '1', 'yes');
INSERT INTO system_text VALUES( '145', 'function.php4', 'Function information', '2', 'function_info');
INSERT INTO system_text VALUES( '146', 'function.php4', 'Edit this function', '2', 'edit_function');
INSERT INTO system_text VALUES( '147', 'function.php4', 'Enter the name of the function', '2', 'enter_name');
INSERT INTO system_text VALUES( '148', 'function.php4', 'Enter a description for the function', '2', 'enter_description');
INSERT INTO system_text VALUES( '149', 'function.php4', 'Enter a example for the use of the function', '2', 'enter_example');
INSERT INTO system_text VALUES( '150', 'function.php4', 'apply changes', '2', 'apply_changes');
INSERT INTO system_text VALUES( '151', 'function.php4', 'The function has been changed', '2', 'changed');
INSERT INTO system_text VALUES( '152', 'function.php4', 'add this new function', '2', 'add_function');
INSERT INTO system_text VALUES( '153', 'function.php4', 'The new function has been created', '2', 'created');
INSERT INTO system_text VALUES( '154', 'function.php4', 'Really delete this function', '2', 'really_delete');
INSERT INTO system_text VALUES( '155', 'function.php4', 'Function name', '2', 'name');
INSERT INTO system_text VALUES( '156', 'function.php4', 'Function description', '2', 'description');
INSERT INTO system_text VALUES( '157', 'function.php4', 'Function use example', '2', 'example');
INSERT INTO system_text VALUES( '158', 'function.php4', 'Yes', '2', 'yes');
INSERT INTO system_text VALUES( '159', 'function.php4', 'No', '2', 'no');
INSERT INTO system_text VALUES( '160', 'function.php4', 'The selected function has been deleted', '2', 'deleted');
INSERT INTO system_text VALUES( '161', 'function.php4', 'Please go to the', '2', 'go_back1');
INSERT INTO system_text VALUES( '162', 'function.php4', 'index page', '2', 'go_back2');
INSERT INTO system_text VALUES( '163', 'function.php4', 'edit function', '2', 'edit_function2');
INSERT INTO system_text VALUES( '164', 'function.php4', 'delete function', '2', 'delete_function');
INSERT INTO system_text VALUES( '165', 'function.php4', 'Add a new function', '2', 'add_function2');
INSERT INTO system_text VALUES( '166', 'function.php4', 'List of parameters', '2', 'parameter_list');
INSERT INTO system_text VALUES( '167', 'function.php4', 'view parameter', '2', 'view_parameter');
INSERT INTO system_text VALUES( '168', 'function.php4', 'edit parameter', '2', 'edit_parameter');
INSERT INTO system_text VALUES( '169', 'function.php4', 'delete parameter', '2', 'delete_parameter');
INSERT INTO system_text VALUES( '170', 'function.php4', 'Add a new parameter', '2', 'add_parameter');
INSERT INTO system_text VALUES( '171', 'function.php4', 'Back to the parent class', '2', 'parent_class');
INSERT INTO system_text VALUES( '188', 'function.php4', 'Funktions Anwendungsbeispiel', '1', 'example');
INSERT INTO system_text VALUES( '187', 'function.php4', 'Geben Sie den Namen der Funktion ein', '1', 'enter_name');
INSERT INTO system_text VALUES( '186', 'function.php4', 'Geben Sie ein Beispiel f�r die Verwendung der Funktion ein', '1', 'enter_example');
INSERT INTO system_text VALUES( '185', 'function.php4', 'Geben Sie eine Beschreibung f�r die Funktion ein', '1', 'enter_description');
INSERT INTO system_text VALUES( '184', 'function.php4', 'Parameter bearbeiten', '1', 'edit_parameter');
INSERT INTO system_text VALUES( '183', 'function.php4', 'Funktion bearbeiten', '1', 'edit_function2');
INSERT INTO system_text VALUES( '182', 'function.php4', 'Diese Funktion bearbeiten', '1', 'edit_function');
INSERT INTO system_text VALUES( '181', 'function.php4', 'Funktionsbeschreibung', '1', 'description');
INSERT INTO system_text VALUES( '180', 'function.php4', 'Parameter l�schen', '1', 'delete_parameter');
INSERT INTO system_text VALUES( '179', 'function.php4', 'Funktion l�schen', '1', 'delete_function');
INSERT INTO system_text VALUES( '178', 'function.php4', 'Die gew�hlte Funktion wurde gel�scht', '1', 'deleted');
INSERT INTO system_text VALUES( '177', 'function.php4', 'Die neue Funktion wurde angelegt', '1', 'created');
INSERT INTO system_text VALUES( '176', 'function.php4', 'Die Funktion wurde ge�ndert', '1', 'changed');
INSERT INTO system_text VALUES( '175', 'function.php4', '�nderungen �bernehmen', '1', 'apply_changes');
INSERT INTO system_text VALUES( '174', 'function.php4', 'Einen neuen Parameter hinzuf�gen', '1', 'add_parameter');
INSERT INTO system_text VALUES( '173', 'function.php4', 'Eine neue Funktion hinzuf�gen', '1', 'add_function2');
INSERT INTO system_text VALUES( '172', 'function.php4', 'Diese neue Funktion hinzuf�gen', '1', 'add_function');
INSERT INTO system_text VALUES( '189', 'function.php4', 'Funktionsinformation', '1', 'function_info');
INSERT INTO system_text VALUES( '190', 'function.php4', 'Bitte gehen Sie zur', '1', 'go_back1');
INSERT INTO system_text VALUES( '191', 'function.php4', 'Index Seite', '1', 'go_back2');
INSERT INTO system_text VALUES( '192', 'function.php4', 'Funktionsname', '1', 'name');
INSERT INTO system_text VALUES( '193', 'function.php4', 'Nein', '1', 'no');
INSERT INTO system_text VALUES( '194', 'function.php4', 'Parameterliste', '1', 'parameter_list');
INSERT INTO system_text VALUES( '195', 'function.php4', 'Zur�ck zur Eltern-Klasse', '1', 'parent_class');
INSERT INTO system_text VALUES( '196', 'function.php4', 'Diese Funktion wirklich l�schen', '1', 'really_delete');
INSERT INTO system_text VALUES( '197', 'function.php4', 'Parameter anzeigen', '1', 'view_parameter');
INSERT INTO system_text VALUES( '198', 'function.php4', 'Ja', '1', 'yes');
INSERT INTO system_text VALUES( '199', 'parameter.php4', 'Parameter information', '2', 'parameter_info');
INSERT INTO system_text VALUES( '200', 'parameter.php4', 'Edit this parameter', '2', 'edit_parameter');
INSERT INTO system_text VALUES( '201', 'parameter.php4', 'Enter the name of the parameter', '2', 'enter_name');
INSERT INTO system_text VALUES( '202', 'parameter.php4', 'Enter the type of the parameter', '2', 'enter_type');
INSERT INTO system_text VALUES( '203', 'parameter.php4', 'Enter a description for the parameter', '2', 'enter_description');
INSERT INTO system_text VALUES( '204', 'parameter.php4', 'Enter a example for the use of the parameter', '2', 'enter_example');
INSERT INTO system_text VALUES( '205', 'parameter.php4', 'apply changes', '2', 'apply_changes');
INSERT INTO system_text VALUES( '206', 'parameter.php4', 'The parameter has been changed', '2', 'changed');
INSERT INTO system_text VALUES( '207', 'parameter.php4', 'Add a new parameter', '2', 'add_parameter');
INSERT INTO system_text VALUES( '208', 'parameter.php4', 'Enter the name of the parameter', '2', 'name');
INSERT INTO system_text VALUES( '209', 'parameter.php4', 'Enter the type of the parameter', '2', 'type');
INSERT INTO system_text VALUES( '210', 'parameter.php4', 'Enter a description for the parameter', '2', 'description');
INSERT INTO system_text VALUES( '211', 'parameter.php4', 'Enter a example for the use of the parameter', '2', 'example');
INSERT INTO system_text VALUES( '212', 'parameter.php4', 'add this new parameter', '2', 'add_parameter2');
INSERT INTO system_text VALUES( '213', 'parameter.php4', 'The new parameter has been created', '2', 'created');
INSERT INTO system_text VALUES( '214', 'parameter.php4', 'Really delete this parameter', '2', 'really_delete');
INSERT INTO system_text VALUES( '215', 'parameter.php4', 'Yes', '2', 'yes');
INSERT INTO system_text VALUES( '216', 'parameter.php4', 'No', '2', 'no');
INSERT INTO system_text VALUES( '217', 'parameter.php4', 'The parameter has been deleted', '2', 'deleted');
INSERT INTO system_text VALUES( '218', 'parameter.php4', 'Please go to the', '2', 'go_back1');
INSERT INTO system_text VALUES( '219', 'parameter.php4', 'index page', '2', 'go_back2');
INSERT INTO system_text VALUES( '220', 'parameter.php4', 'Delete parameter', '2', 'delete_parameter');
INSERT INTO system_text VALUES( '221', 'parameter.php4', 'Back to the parent function', '2', 'parent_class');
INSERT INTO system_text VALUES( '222', 'parameter.php4', 'Einen neuen Parameter hinzuf�gen', '1', 'add_parameter');
INSERT INTO system_text VALUES( '223', 'parameter.php4', 'Diesen neuen Parameter hinzuf�gen', '1', 'add_parameter2');
INSERT INTO system_text VALUES( '224', 'parameter.php4', '�nderungen durchf�hren', '1', 'apply_changes');
INSERT INTO system_text VALUES( '225', 'parameter.php4', 'Der Parameter wurde ge�ndert', '1', 'changed');
INSERT INTO system_text VALUES( '226', 'parameter.php4', 'Der neue Parameter wurde angelegt', '1', 'created');
INSERT INTO system_text VALUES( '227', 'parameter.php4', 'Der Parameter wurde gel�scht', '1', 'deleted');
INSERT INTO system_text VALUES( '228', 'parameter.php4', 'Parameter l�schen', '1', 'delete_parameter');
INSERT INTO system_text VALUES( '229', 'parameter.php4', 'Geben Sie eine Beschreibung f�r den Parameter ein', '1', 'description');
INSERT INTO system_text VALUES( '230', 'parameter.php4', '�ndern diese Parameters', '1', 'edit_parameter');
INSERT INTO system_text VALUES( '231', 'parameter.php4', 'Beschreibung f�r den Parameter eingeben', '1', 'enter_description');
INSERT INTO system_text VALUES( '232', 'parameter.php4', 'Geben Sie ein Anwendungsbeispiel des Parameters an', '1', 'enter_example');
INSERT INTO system_text VALUES( '233', 'parameter.php4', 'Geben Sie den Namen des Parameters ein', '1', 'enter_name');
INSERT INTO system_text VALUES( '234', 'parameter.php4', 'Geben Sie den Typ von Parameter ein', '1', 'enter_type');
INSERT INTO system_text VALUES( '235', 'parameter.php4', 'Geben Sie ein Beispiel f�r die Nutzung des Parameters an', '1', 'example');
INSERT INTO system_text VALUES( '236', 'parameter.php4', 'Bitte gehen Sie zur', '1', 'go_back1');
INSERT INTO system_text VALUES( '237', 'parameter.php4', 'Index Seite', '1', 'go_back2');
INSERT INTO system_text VALUES( '238', 'parameter.php4', 'Geben Sie den Namen des Parameters ein', '1', 'name');
INSERT INTO system_text VALUES( '239', 'parameter.php4', 'Nein', '1', 'no');
INSERT INTO system_text VALUES( '240', 'parameter.php4', 'Parameter Information', '1', 'parameter_info');
INSERT INTO system_text VALUES( '241', 'parameter.php4', 'Zur�ck zur Eltern-Funktion', '1', 'parent_class');
INSERT INTO system_text VALUES( '242', 'parameter.php4', 'Diesen Parameter wirklich l�schen', '1', 'really_delete');
INSERT INTO system_text VALUES( '243', 'parameter.php4', 'Geben Sie den Typ des Parameters ein', '1', 'type');
INSERT INTO system_text VALUES( '244', 'parameter.php4', 'Ja', '1', 'yes');

# --------------------------------------------------------
#
# Tabellenstruktur f�r Tabelle 'to_do'
#

DROP TABLE IF EXISTS to_do;
CREATE TABLE to_do (
   row_id int(11) DEFAULT '0' NOT NULL auto_increment,
   table_name varchar(255) NOT NULL,
   table_row_id int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (row_id),
   KEY row_id (row_id),
   UNIQUE row_id_2 (row_id)
);
