phpDoc - version 0.2.1
http://sourceforge.net/project/?group_id=6109

README

For PHP programmers who work as a group and who want to use classes and functions 
in their development it is difficult to distribute and update the required 
documentation.

phpDoc provides a (not yet very sophisticated) method of managing information
about your classes and functions. You can add projects, classes, functions and
their parameters. For each of them you can define a name, a description and an
example.

The multilanguage support for the user interface is working now. The translation
pages for the content are not ready yet.

The administration pages for the multilanguage support can be found in the admin 
folder (just open /admin/index.php4 in your webbrowser).

In a future version phpDoc should support a possibility to give several users the
possibility to work locally and merge their entries into a central online source
(still thinking how to do this ;)

Information about the installation can be found in the INSTALL file.


KNOWN BUGS

* When you delete a non empty project, class or function the attached class, 
  functions and parameters are not deleted.

Please feel free to send bugreports, feature requests or modifications here:
http://sourceforge.net/project/?group_id=6109

Goeran Zaengerlein
goeran@zaengerlein.de
last modification: 1st June 2000