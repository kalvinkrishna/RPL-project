<?php
/**
 * Unit Tests for the IntermediateParser->addPrivatePage() method
 * @package tests
 * @subpackage PhpDocumentorUnitTests
 * @author Chuck Burgess
 * @since 1.4.0a2
 */

/**
 * Obtain the helper file.
 */
require_once dirname(__FILE__) . '/helper.inc';

/**
 * Unit Testing of the IntermediateParser's addPrivatePage() method
 * @package tests
 * @subpackage PhpDocumentorUnitTests
 * @author Chuck Burgess
 * @since 1.4.0a2
 */
class IntermediateParserAddPrivatePageTest extends PHPUnit_Framework_TestCase {

    /**
     * @var phpDocumentor_setup
     * @access private
     * @since 1.4.0a2
     */
    private $ps;
    /**
     * @var phpDocumentor_IntermediateParser
     * @access private
     * @since 1.4.0a2
     */
    private $ip;
    /**
     * @var parserPage
     * @access private
     * @since 1.4.0a2
     */
    private $pp;
    /**
     * @var parserData
     * @access private
     * @since 1.4.0a2
     */
    private $pd;
    /**
     * path to file string
     * @access private
     * @since 1.4.0a2
     */
    private $path;

    /**
     * Sets up the fixture, for example, open a network connection.
     * This method is called before a test is executed.
     * @access protected
     * @since 1.4.0a2
     */
    protected function setUp() {
        $GLOBALS['_phpDocumentor_install_dir'] = PHPDOCUMENTOR_BASE;
        $GLOBALS['_phpDocumentor_setting']['quiet'] = "on";

        $this->ps = new phpDocumentor_setup();
        $this->ip = new phpDocumentor_IntermediateParser();
        $this->pp = new parserPage();
        $this->pd = new ParserData;
        $this->pd->package = 'TESTING';
        $this->path = PHPDOCUMENTOR_BASE . 'TestFile.php';
        $this->ip->pages = array($this->path => $this->pd);
    }

    /**
     * Tears down the fixture, for example, close a network connection.
     * This method is called after a test is executed.
     * @access protected
     * @since 1.4.0a2
     */
    protected function tearDown() {
        unset($this->path);
        unset($this->pd);
        unset($this->pp);
        unset($this->ip);
        unset($this->ps);
    }


    /**
     * NOW LIST THE TEST CASES -------------------------------------------------------|
     */

    /**
     * normal, expected cases ------------------------------------------|
     */

    /**
     * demonstrate the correct behavior -----------------------|
     */

    /**
     * Shows correct behavior for adding a private page object,
     * when the privatepages array already has an element
     * @since 1.4.0a2
     */
    public function testShowCorrectBehaviorWhenPrivatePageArrayIsNotAlreadyEmpty() {
        $this->ip->privatepages = array($this->path => $this->pd);
        $this->ip->addPrivatePage($this->pp, $this->path);

        // verify parent attributes are set correctly
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->type, "page");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->id, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->file, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->sourceLocation, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->name, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->origName, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->category, "default");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->package, "default");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->subpackage, "");
        /**
         * don't bother checking '[$this->path]->parent->parserVersion,
         * because it will change between PhpDocumentor versions,
         * and we don't want to keep it hand-updated in here
         */
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->modDate, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->path, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->packageOutput, "");

        // now verify current page attributes are set correctly
        $this->assertEquals($this->ip->privatepages[$this->path]->elements, array());
        $this->assertEquals($this->ip->privatepages[$this->path]->_hasclasses, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->_hasinterfaces, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->privateelements, array());
        $this->assertEquals($this->ip->privatepages[$this->path]->classelements, array());
        $this->assertEquals($this->ip->privatepages[$this->path]->tutorial, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->privateclasselements, array());
        $this->assertEquals($this->ip->privatepages[$this->path]->links, array());
        $this->assertEquals($this->ip->privatepages[$this->path]->clean, true);
        $this->assertEquals($this->ip->privatepages[$this->path]->docblock, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->_explicitdocblock, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->type, "page");
        $this->assertEquals($this->ip->privatepages[$this->path]->package, "TESTING");
    }
    /**
     * Shows correct behavior for adding a private page object,
     * when the privatepages array is completely empty
     * @since 1.4.0a2
     */
    public function testShowCorrectBehaviorWhenPrivatePageArrayIsEmpty() {
        $this->ip->addPrivatePage($this->pp, $this->path);

        // verify parent attributes are set correctly
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->type, "page");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->id, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->file, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->sourceLocation, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->name, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->origName, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->category, "default");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->package, "default");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->subpackage, "");
        /**
         * don't bother checking '[$this->path]->parent->parserVersion,
         * because it will change between PhpDocumentor versions,
         * and we don't want to keep it hand-updated in here
         */
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->modDate, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->path, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->parent->packageOutput, "");

        // now verify current page attributes are set correctly
        $this->assertEquals($this->ip->privatepages[$this->path]->elements, array());
        $this->assertEquals($this->ip->privatepages[$this->path]->_hasclasses, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->_hasinterfaces, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->privateelements, array());
        $this->assertEquals($this->ip->privatepages[$this->path]->classelements, array());
        $this->assertEquals($this->ip->privatepages[$this->path]->tutorial, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->privateclasselements, array());
        $this->assertEquals($this->ip->privatepages[$this->path]->links, array());
        $this->assertEquals($this->ip->privatepages[$this->path]->clean, true);
        $this->assertEquals($this->ip->privatepages[$this->path]->docblock, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->_explicitdocblock, "");
        $this->assertEquals($this->ip->privatepages[$this->path]->type, "page");
    }

    /**
     * END OF "demonstrate the correct behavior" --------------|
     */
    /**
     * END OF "normal, expected cases" ---------------------------------|
     * @todo write more "normal" test cases
     */


    /**
     * odd, edge cases -------------------------------------------------|
     */
    /**
     * END OF "odd, edge cases" ----------------------------------------|
     * @todo write some "edge" test cases
     */

    /**
     * END OF "NOW LIST THE TEST CASES" ----------------------------------------------|
     */
}
