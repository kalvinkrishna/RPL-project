<?php
/**
* Im a page level docblock
*
* @package tests
*/


/**
* Im a dummy function currently you need at least one function in your procedural page for this to work
*/
function dummy()
{
}
?>
