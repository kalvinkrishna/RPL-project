<?php
/** @package tests */
/**
* test function
* @author Joshua Eichorn <jeichorn@phpdoc.org>
* @link	http://www.phpdoc.org
*/
function test_authoremail ()
{
}
