<?php
/**
* @package tests
*/
/**
* @package tests
*/
class brokenlinkstovars
{
	var $broken;
	/**
	* @see $broken
	*/
	function brokenlinkstovars()
	{
	}
}
?>