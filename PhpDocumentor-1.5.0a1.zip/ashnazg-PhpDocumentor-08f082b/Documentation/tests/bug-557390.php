<?php
/**
* @package tests
*/
/**
* @package tests
*/
class few
{
/******===really fancy===****
* my * is ignored
*/
var $pfh;
}
?>